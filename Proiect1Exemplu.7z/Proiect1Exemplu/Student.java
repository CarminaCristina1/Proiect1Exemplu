public class Student{
    public String nume;
    public String prenume;
    public int nrMatricol;
    public int notaPOO;
    
    public Student (String nume, String prenume, int nrMatricol){
        this.nume = nume;
        this.prenume = prenume;
        this.nrMatricol = nrMatricol;
    }
}