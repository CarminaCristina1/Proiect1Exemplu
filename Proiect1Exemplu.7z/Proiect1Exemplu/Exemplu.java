import java.io.Console;
import java.util.ArrayList;

public class Exemplu{
    public static void main (String args[])
    {
        ArrayList<Student> studenti = new ArrayList<Student>();

        Student s1 = new Student("Ionescu","Ion",12345);
        s1.notaPOO = 10;
        
        Student s2 = new Student("Gheorghe","George",23456);
        s2.notaPOO = 9;

        studenti.add(s1);
        studenti.add(s2);
        int alegere = 1;
        String ceva;
        Console cnsl = System.console();
        while(alegere != 0){
            System.out.println( "Te rog alege ce doresti sa faci!\n 1) Introdu Student.\n2) Afiseaza media."+
            "\n3) Afiseaza student dupa numarul matricol.\n0) Exit");
            ceva = cnsl.readLine();
            try{
                alegere = Integer.parseInt(ceva);
            }
            catch(Exception ex){
                System.out.println("Te rog alege cu atentie!! Tasteaza un numar de la 0 la 3 in functie de ce doresti sa executi!!\n 1) Introdu Student.\n2) Afiseaza media."+
            "\n3) Afiseaza student dupa numarul matricol.\n0) Exit");
            }
            while(alegere < 0 || alegere > 3){
                ceva = cnsl.readLine();
                try{
                    alegere = Integer.parseInt(ceva);
                }
                catch(Exception ex){
                    System.out.println("Alege cu atentie!");
                }
            }

            switch(alegere){
                case 1:
                    System.out.println("Introduceti numele: ");
                    String name = cnsl.readLine();
                    System.out.println("Introduceti prenumele: ");
                    String prename = cnsl.readLine();
                    System.out.println("Nota OOP: ");
                    int notaPOO = Integer.parseInt(cnsl.readLine());
                    System.out.println("Numar matricol: ");
                    int nrMatricol = Integer.parseInt(cnsl.readLine());
                    Student student = new Student(name, prename, nrMatricol);
                    student.notaPOO = notaPOO;
                    studenti.add(student);
                    System.out.println("Am adaugat studentul: " + name + " " + prename + " nota oop: " + notaPOO + " nrMatricol: " + nrMatricol);
                    break;
                case 2:
                    int note = 0;
                    for (Student stud : studenti) {
                        note += stud.notaPOO;
                    }
                    System.out.println("Media notelor este " + (note / studenti.size()));
                    break;
                case 3:
                    System.out.println("Numar matricol: ");
                    int nrMatricol1 = Integer.parseInt(cnsl.readLine());
                    for (Student stud : studenti) {
                        if(nrMatricol1 == stud.nrMatricol){
                            System.out.println("Am adaugat studentul: " + stud.nume + " " + stud.prenume + " nota oop: " + stud.notaPOO + " nrMatricol: " + stud.nrMatricol);
                            break;
                        }
                    }
                    break;
                default:
                    System.out.println("PAAA");
                    break;
            }
        }
    }
}